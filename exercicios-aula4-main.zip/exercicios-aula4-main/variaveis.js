let nome = 'Bruno'
let idade = '19'

console.log(`Olá, meu nome é ${nome} e eu tenho ${idade} anos`)